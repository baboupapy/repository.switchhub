# -*- coding: utf-8 -*-

import os
import zipfile
import xbmcgui
import xbmcvfs
from datetime import datetime
from resources.lib.utils_type import kodi_to_real

HOME = xbmcvfs.translatePath("special://home/")
ADDONS = os.path.join(HOME, "addons")
USERDATA = os.path.join(HOME, "userdata")

EXCLUDED_USERDATA_DIRS = ["thumbnails", "cache", "temp", "packages", "database"]
EXCLUDED_USERDATA_FILES = [".log", ".db-journal"]
EXCLUDED_ADDONS_FILES = [".dll", ".so", ".dylib", ".pyd", ".exe", ".bin", ".dat", ".lock"]


def backup_full(dest_folder):

    dest_real = kodi_to_real(dest_folder)

    temp_dir = xbmcvfs.translatePath("special://home/temp/")
    if not xbmcvfs.exists(temp_dir):
        xbmcvfs.mkdirs(temp_dir)

    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    zip_name = f"backup_full_{stamp}.zip"
    local_zip = os.path.join(temp_dir, zip_name)

    dp = xbmcgui.DialogProgress()
    dp.create("SwitchHub Migrate", "Sauvegarde complète...")

    try:
        zipf = zipfile.ZipFile(local_zip, "w", zipfile.ZIP_DEFLATED)
    except Exception as e:
        xbmcgui.Dialog().ok("SwitchHub Migrate", f"Erreur ZIP : {e}")
        return False

    zipf.writestr("type.txt", "full")

    # -----------------------------
    # ADDONS — progression fluide
    # -----------------------------
    dp.update(10, "Analyse des addons...")

    addons_files = []
    for base, dirs, files in os.walk(ADDONS):
        for f in files:
            if not f.lower().endswith(tuple(EXCLUDED_ADDONS_FILES)):
                addons_files.append((base, f))

    total_addons = len(addons_files)
    count = 0

    dp.update(15, "Sauvegarde des addons...")

    for base, f in addons_files:
        count += 1

        rel = os.path.relpath(base, ADDONS).replace("\\", "/")
        zip_root = "addons/" + (rel + "/" if rel != "." else "")
        src = os.path.join(base, f)
        arc = zip_root + f

        try:
            zipf.write(src, arc)
        except Exception:
            pass

        dp.update(int(15 + (count / total_addons) * 40), f"Addons : {f}")

    # -----------------------------
    # USERDATA — progression fluide
    # -----------------------------
    dp.update(60, "Analyse du userdata...")

    userdata_files = []
    for base, dirs, files in os.walk(USERDATA):
        lower_base = base.lower()
        if any(x in lower_base for x in EXCLUDED_USERDATA_DIRS):
            continue

        for f in files:
            if not f.lower().endswith(tuple(EXCLUDED_USERDATA_FILES)):
                userdata_files.append((base, f))

    total_userdata = len(userdata_files)
    count = 0

    dp.update(65, "Sauvegarde du userdata...")

    for base, f in userdata_files:
        count += 1

        rel = os.path.relpath(base, USERDATA).replace("\\", "/")
        zip_root = "userdata/" + (rel + "/" if rel != "." else "")
        src = os.path.join(base, f)
        arc = zip_root + f

        try:
            zipf.write(src, arc)
        except Exception:
            pass

        dp.update(int(65 + (count / total_userdata) * 30), f"Userdata : {f}")

    zipf.close()

    # -----------------------------
    # COPIE USB / SMB — fenêtre visible
    # -----------------------------
    dp.update(95, "Copie du fichier de sauvegarde...\nPatientez...")

    if dest_folder.lower().startswith("smb://"):
        final_zip = os.path.join(dest_folder, zip_name)
        xbmcvfs.copy(local_zip, final_zip)
    else:
        final_zip = os.path.join(dest_real, zip_name)
        xbmcvfs.copy(local_zip, final_zip)

    dp.update(100, "Finalisation...")
    dp.close()

    xbmcgui.Dialog().ok("SwitchHub Migrate", "Sauvegarde complète terminée.")
    return True


def run_backup_full():
    dialog = xbmcgui.Dialog()
    dest = dialog.browse(0, "Choisissez un dossier de sauvegarde", "")
    if not dest:
        xbmcgui.Dialog().ok("SwitchHub Migrate", "Aucun dossier sélectionné.")
        return
    backup_full(dest)


















   















        
        
        
