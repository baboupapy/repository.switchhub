# -*- coding: utf-8 -*-

import os
import xbmcvfs
import xbmcgui

def ensure_dir(path):
    """Crée un dossier si nécessaire."""
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

def allowed_path(path):
    """Empêche l’écriture dans les dossiers interdits."""
    lower = path.lower()
    forbidden = ["temp", "cache", "thumbnails", "packages", "log"]
    return not any(x in lower for x in forbidden)

def notify(title, message):
    """Affiche une notification simple."""
    xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, 3000)







   















        
        
        
