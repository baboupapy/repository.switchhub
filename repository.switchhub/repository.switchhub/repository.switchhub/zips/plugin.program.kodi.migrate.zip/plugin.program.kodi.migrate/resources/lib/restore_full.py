# -*- coding: utf-8 -*-

import os
import xbmcgui
import xbmcvfs
import zipfile
from resources.lib.utils_type import get_backup_type, kodi_to_real, smb_to_local

HOME = xbmcvfs.translatePath("special://home/")

def restore_full(zip_path):
    # Convertir chemin Kodi → réel
    zip_real = kodi_to_real(zip_path)

    # Si ZIP SMB → copier local
    if zip_path.lower().startswith("smb://"):
        zip_real = smb_to_local(zip_real)

    # Vérifier type
    t = get_backup_type(zip_real)
    if t != "full":
        xbmcgui.Dialog().ok("SwitchHub Migrate", "Ce fichier n’est pas une sauvegarde complète.")
        return False

    dp = xbmcgui.DialogProgress()
    dp.create("SwitchHub Migrate", "Restauration complète...")

    try:
        zin = zipfile.ZipFile(zip_real, "r")
    except Exception as e:
        xbmcgui.Dialog().ok("SwitchHub Migrate", f"Erreur ZIP : {e}")
        return False

    names = zin.namelist()
    norm = [n.replace("\\", "/").lstrip("./") for n in names]

    root = ""
    for n in norm:
        if n.endswith("type.txt"):
            root = n.replace("type.txt", "")
            break

    file_list = [
        f for f in norm
        if f.startswith(root + "addons/") or f.startswith(root + "userdata/")
    ]

    total = float(len(file_list))
    count = 0

    for f in file_list:
        count += 1
        dp.update(int((count / total) * 100), f"Restauration...\n{f}")

        rel = f[len(root):]
        target = os.path.join(HOME, rel)
        base = os.path.dirname(target)

        if not xbmcvfs.exists(base):
            xbmcvfs.mkdirs(base)

        try:
            zin.extract(f, HOME)
        except Exception:
            continue

        if dp.iscanceled():
            zin.close()
            dp.close()
            xbmcgui.Dialog().ok("SwitchHub Migrate", "Restauration annulée.")
            return False

    zin.close()
    dp.close()
    xbmcgui.Dialog().ok("SwitchHub Migrate", "Restauration complète terminée.")
    return True

def run_restore_full():
    dialog = xbmcgui.Dialog()
    zip_path = dialog.browse(1, "Sélectionnez une sauvegarde complète (ZIP)", "")
    if not zip_path:
        xbmcgui.Dialog().ok("SwitchHub Migrate", "Aucun fichier sélectionné.")
        return
    restore_full(zip_path)





















   















        
        
        
