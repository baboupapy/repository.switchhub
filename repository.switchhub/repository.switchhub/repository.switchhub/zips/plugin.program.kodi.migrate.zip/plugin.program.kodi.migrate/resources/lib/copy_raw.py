# -*- coding: utf-8 -*-

import os
import xbmcgui
import xbmcvfs

def copy_raw(src, dest, title, folder_name=None):
    dp = xbmcgui.DialogProgress()
    dp.create("SwitchHub Migrate", title)

    if folder_name:
        dest = os.path.join(dest, folder_name)
        if not xbmcvfs.exists(dest):
            xbmcvfs.mkdirs(dest)

    for base, dirs, files in os.walk(src):
        rel = os.path.relpath(base, src).replace("\\", "/")
        target_dir = os.path.join(dest, rel)

        if not xbmcvfs.exists(target_dir):
            xbmcvfs.mkdirs(target_dir)

        for f in files:
            src_file = os.path.join(base, f)
            dest_file = os.path.join(target_dir, f)

            dp.update(0, f"Copie...\n{dest_file}")
            xbmcvfs.copy(src_file, dest_file)

    dp.close()
    xbmcgui.Dialog().ok("SwitchHub Migrate", "Copie terminée.")


   















        
        
        
