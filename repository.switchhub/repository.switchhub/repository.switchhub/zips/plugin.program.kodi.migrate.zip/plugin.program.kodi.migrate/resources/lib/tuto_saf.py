# -*- coding: utf-8 -*-

import xbmcgui

def show():
    xbmcgui.Dialog().ok(
        "Kodi Migrate - Tuto SAF",
        "Android 11+ bloque l’accès aux disques externes (USB, SD, media_rw).\n\n"
        "SAF est la fenêtre officielle d’Android qui permet d’autoriser Kodi "
        "à lire et écrire dans un dossier externe.\n\n"
        "Comment l’utiliser :\n"
        "1. Choisissez votre dossier (USB, SD, interne…)\n"
        "2. Cliquez sur 'Utiliser ce dossier'\n"
        "3. Confirmez 'Autoriser Kodi à accéder à ce dossier'\n\n"
        "Une fois validé, ce dossier sera utilisé pour les sauvegardes "
        "et restaurations."
    )


   















        
        
        
