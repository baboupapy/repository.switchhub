# -*- coding: utf-8 -*-

import os
import zipfile
import xbmcgui
import xbmcvfs
from datetime import datetime
from resources.lib.utils_type import kodi_to_real, smb_to_local

HOME = xbmcvfs.translatePath("special://home/")
ADDON_DATA = os.path.join(HOME, "userdata", "addon_data")

def backup_simple(dest_folder):
    from resources.lib.utils_type import kodi_to_real

    # Convertir le chemin Kodi → réel
    dest_real = kodi_to_real(dest_folder)

    # Le ZIP sera créé LOCAL, puis copié vers SMB si nécessaire
    temp_dir = xbmcvfs.translatePath("special://home/temp/")
    if not xbmcvfs.exists(temp_dir):
        xbmcvfs.mkdirs(temp_dir)

    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    zip_name = f"backup_simple_{stamp}.zip"
    local_zip = os.path.join(temp_dir, zip_name)

    dp = xbmcgui.DialogProgress()
    dp.create("SwitchHub Migrate", "Sauvegarde simple...")

    try:
        zipf = zipfile.ZipFile(local_zip, "w", zipfile.ZIP_DEFLATED)
    except Exception as e:
        xbmcgui.Dialog().ok("SwitchHub Migrate", f"Erreur ZIP : {e}")
        return False

    zipf.writestr("type.txt", "simple")

    ADDON_DATA = os.path.join(HOME, "userdata", "addon_data")

    for base, dirs, files in os.walk(ADDON_DATA):
        rel = os.path.relpath(base, ADDON_DATA).replace("\\", "/")
        zip_root = "addon_data/" + (rel + "/" if rel != "." else "")

        for f in files:
            src = os.path.join(base, f)
            arc = zip_root + f
            try:
                zipf.write(src, arc)
            except Exception:
                pass

    zipf.close()
    dp.update(100)
    dp.close()

    # Si la destination est SMB → copier le ZIP local vers le NAS
    if dest_folder.lower().startswith("smb://"):
        nas_zip = os.path.join(dest_folder, zip_name)
        xbmcvfs.copy(local_zip, nas_zip)
    else:
        # Destination locale → copier directement
        final_zip = os.path.join(dest_real, zip_name)
        xbmcvfs.copy(local_zip, final_zip)

    xbmcgui.Dialog().ok("SwitchHub Migrate", "Sauvegarde simple terminée.")
    return True


def run_backup_simple():
    dialog = xbmcgui.Dialog()
    dest = dialog.browse(0, "Choisissez un dossier de sauvegarde", "")
    if not dest:
        xbmcgui.Dialog().ok("SwitchHub Migrate", "Aucun dossier sélectionné.")
        return
    backup_simple(dest)






































   















        
        
        
