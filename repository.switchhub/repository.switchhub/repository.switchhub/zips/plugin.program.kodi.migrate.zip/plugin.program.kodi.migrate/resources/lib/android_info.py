# -*- coding: utf-8 -*-

import sys
import xbmc

def is_android():
    return sys.platform.startswith("android")

def android_version():
    """
    Retourne la version Android (int) ou None si non Android.
    """
    if not is_android():
        return None

    try:
        version = xbmc.getInfoLabel("System.BuildVersion")
        # Exemple : "Android 12 (SDK 31)"
        if "Android" in version:
            parts = version.split()
            return int(parts[1])
    except:
        pass

    return None

def saf_available():
    """
    SAF est disponible uniquement sous Android 11+.
    """
    if not is_android():
        return False

    version = android_version()
    if version is None:
        return False

    return version >= 11

   















        
        
        
