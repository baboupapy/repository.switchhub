# -*- coding: utf-8 -*-

import os

def estimate_folder_size(path):
    total = 0
    for base, dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(base, f))
            except:
                pass
    return total

def get_free_space(path):
    try:
        stat = os.statvfs(path)
        return stat.f_bavail * stat.f_frsize
    except:
        return 0



   















        
        
        
