# -*- coding: utf-8 -*-

import xbmc

def is_android():
    return xbmc.getCondVisibility("System.Platform.Android")

def is_windows():
    return xbmc.getCondVisibility("System.Platform.Windows")

def is_linux():
    return xbmc.getCondVisibility("System.Platform.Linux")


   















        
        
        
