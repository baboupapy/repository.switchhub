# -*- coding: utf-8 -*-

import xbmcgui
import xbmcvfs
import os

CONFIG_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.program.kodi.migrate"
)
SAF_FILE = os.path.join(CONFIG_DIR, "saf_path.txt")


def load_saf_path():
    if os.path.exists(SAF_FILE):
        with open(SAF_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    return None


def choose_folder():
    folder = xbmcgui.Dialog().browse(
        3, "Choisir un dossier via SAF", "files", "", False, False, ""
    )

    if not folder:
        xbmcgui.Dialog().ok("Kodi Migrate - SAF", "Aucun dossier sélectionné.")
        return None

    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)

    with open(SAF_FILE, "w", encoding="utf-8") as f:
        f.write(folder)

    xbmcgui.Dialog().notification(
        "Kodi Migrate",
        f"Dossier SAF sélectionné : {folder}",
        xbmcgui.NOTIFICATION_INFO,
        5000
    )

    return folder





   















        
        
        
