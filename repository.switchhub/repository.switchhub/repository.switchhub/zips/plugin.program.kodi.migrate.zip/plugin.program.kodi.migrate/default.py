# -*- coding: utf-8 -*-

import sys
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmc

from resources.lib.backup_simple import run_backup_simple
from resources.lib.backup_full import run_backup_full
from resources.lib.restore_simple import run_restore_simple
from resources.lib.restore_full import run_restore_full

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])


def ensure_estuary():
    skin = xbmc.getSkinDir()
    if skin != "skin.estuary":
        xbmcgui.Dialog().yesno(
            "SwitchHub Migrate",
            "Ce module doit être exécuté sous le skin Estuary.\n"
            "Veuillez basculer sur Estuary.",
            nolabel="OK",
            yeslabel=""
        )
        raise SystemExit

ensure_estuary()


def add_item(label, action):
    url = f"{sys.argv[0]}?action={action}"
    li = xbmcgui.ListItem(label)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, False)


def main_menu():
    add_item("Sauvegarde simple", "backup_simple")
    add_item("Sauvegarde complète", "backup_full")
    add_item("Restauration simple", "restore_simple")
    add_item("Restauration complète", "restore_full")
    xbmcplugin.endOfDirectory(HANDLE)


def router(paramstring):
    import urllib.parse
    params = dict(urllib.parse.parse_qsl(paramstring))

    action = params.get("action")

    if action is None:
        main_menu()
        return

    if action == "backup_simple":
        run_backup_simple()
    elif action == "backup_full":
        run_backup_full()
    elif action == "restore_simple":
        run_restore_simple()
    elif action == "restore_full":
        run_restore_full()
    else:
        xbmcgui.Dialog().ok("SwitchHub Migrate", f"Action inconnue : {action}")


if __name__ == "__main__":
    router(sys.argv[2][1:])



































        
        
        
