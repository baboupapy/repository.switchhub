SwitchHub Migrate – Sauvegarde & Restauration Kodi
SwitchHub Migrate est un outil simple et fiable pour sauvegarder et restaurer Kodi sur tous les appareils :
Windows, Linux, CoreELEC, Android, Android 11 et +.

Depuis Android 11, l’accès aux fichiers est fortement limité, ce qui rend les sauvegardes classiques difficiles ou impossibles. SwitchHub Migrate contourne ces restrictions en utilisant une méthode intelligente qui s’adapte automatiquement à la mémoire disponible.

🟩 Fonctionnalités
✔ Sauvegarde complète
Copie les dossiers essentiels de Kodi :

addons/

userdata/

Avec exclusion automatique des dossiers temporaires ou inutiles.

✔ Sauvegarde simple
Copie uniquement :

userdata/addon_data/  
Idéal pour transférer les réglages des addons.

✔ Restauration complète ou simple
Compatible avec toutes les plateformes :

Windows

Linux

CoreELEC

Android

Android 11+

Nvidia Shield

FireTV

NAS / USB / disques externes

✔ Mode intelligent ZIP / Copie directe
Si l’appareil a assez de mémoire → sauvegarde ZIP

Si la mémoire est limitée → sauvegarde non compressée (copie directe)
Les deux formats sont entièrement restaurables sur n’importe quel appareil, même plus puissant.

✔ Extraction sécurisée
Restauration fichier par fichier, avec contrôle des permissions, pour éviter les erreurs.

✔ Nettoyage automatique
Le dossier temporaire utilisé par l’addon est nettoyé après chaque opération.

🟩 Pourquoi SwitchHub Migrate ?
Android 11+ limite fortement l’accès aux fichiers, ce qui empêche Kodi de sauvegarder ou restaurer ses dossiers internes.
SwitchHub Migrate fournit une solution fiable, compatible et simple pour :

migrer Kodi d’un appareil à un autre

sauvegarder une configuration complète

restaurer proprement sans erreurs

utiliser Kodi sur des appareils à petite mémoire ou sur des plateformes puissantes comme la Shield

🟩 Installation
Télécharger le ZIP de l’addon

Kodi → Addons → Installer depuis un ZIP

Ouvrir SwitchHub Migrate

Choisir :

Sauvegarde simple

Sauvegarde complète

Restauration simple

Restauration complète

🟩 Licence
Libre d’utilisation et de modification.