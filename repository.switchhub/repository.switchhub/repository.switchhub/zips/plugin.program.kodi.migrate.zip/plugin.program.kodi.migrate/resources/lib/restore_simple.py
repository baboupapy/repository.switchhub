# -*- coding: utf-8 -*-

import os
import xbmcgui
import xbmcvfs
import zipfile
import tempfile

from resources.lib.copy_raw import copy_raw
from resources.lib.utils_type import get_backup_type

USERDATA = xbmcvfs.translatePath("special://home/userdata/")
ADDON_DATA = os.path.join(USERDATA, "addon_data")


# ------------------------------------------------------------
#  RESTAURATION SIMPLE — NAS (smb://)
#  MODE FIABLE : copie brute → restauration locale
# ------------------------------------------------------------
def restore_simple_nas(zip_path):
    progress = xbmcgui.DialogProgress()
    progress.create("SwitchHub Migrate", "Copie du ZIP NAS...")

    try:
        # Copie NAS → LOCAL via API Kodi (fiable)
        tmp_zip = tempfile.mktemp(suffix="_nas_simple.zip")
        xbmcvfs.copy(zip_path, tmp_zip)

        progress.update(100, "Copie NAS terminée")
        progress.close()

        # Restauration locale (fiable)
        return restore_simple_local(tmp_zip)

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok("SwitchHub Migrate", f"Erreur NAS : {repr(e)}")
        return False



# ------------------------------------------------------------
#  RESTAURATION SIMPLE — LOCAL / USB
# ------------------------------------------------------------
def restore_simple_local(zip_path):
    t = get_backup_type(zip_path)
    if t != "simple":
        xbmcgui.Dialog().ok("SwitchHub Migrate", "Ce fichier n’est pas une sauvegarde simple.")
        return False

    dp = xbmcgui.DialogProgress()
    dp.create("SwitchHub Migrate", "Restauration simple locale...")

    try:
        zin = zipfile.ZipFile(zip_path, "r")
    except Exception as e:
        xbmcgui.Dialog().ok("SwitchHub Migrate", f"Erreur ZIP : {e}")
        return False

    names = zin.namelist()
    norm = [n.replace("\\", "/").lstrip("./") for n in names]

    root = ""
    for n in norm:
        if n.endswith("type.txt"):
            root = n.replace("type.txt", "")
            break

    file_list = [f for f in norm if f.startswith(root + "addon_data/")]

    total = float(len(file_list))
    count = 0

    for f in file_list:
        count += 1
        rel = f[len(root + "addon_data/"):].lstrip("/\\")
        target = os.path.join(ADDON_DATA, rel)

        dp.update(int((count / total) * 100), f"Restauration...\n{rel}")

        base = os.path.dirname(target)
        if not xbmcvfs.exists(base):
            xbmcvfs.mkdirs(base)

        try:
            with zin.open(f) as src:
                with xbmcvfs.File(target, 'w') as dst:
                    dst.write(src.read())
        except Exception as e:
            zin.close()
            dp.close()
            xbmcgui.Dialog().ok("SwitchHub Migrate", f"Erreur extraction : {e}")
            return False

        if dp.iscanceled():
            zin.close()
            dp.close()
            xbmcgui.Dialog().ok("SwitchHub Migrate", "Restauration annulée.")
            return False

    zin.close()
    dp.close()
    xbmcgui.Dialog().ok("SwitchHub Migrate", "Restauration simple locale terminée.")
    return True


# ------------------------------------------------------------
#  ROUTEUR : NAS / USB / LOCAL
# ------------------------------------------------------------
def run_restore_simple():
    dialog = xbmcgui.Dialog()
    zip_path = dialog.browse(1, "Sélectionnez une sauvegarde simple (ZIP)", "")

    if not zip_path:
        xbmcgui.Dialog().ok("SwitchHub Migrate", "Aucun fichier sélectionné.")
        return

    # NAS
    if zip_path.lower().startswith("smb://"):
        restore_simple_nas(zip_path)
        return

    # USB (copie brute)
    if "media" in zip_path.lower() or "usb" in zip_path.lower():
        copy_raw(zip_path, USERDATA, "Restauration simple USB", folder_name="addon_data")
        return

    # LOCAL
    restore_simple_local(zip_path)






























   















        
        
        
