# -*- coding: utf-8 -*-

import xbmcvfs

def get_kodi_userdata():
    userdata = xbmcvfs.translatePath("special://userdata")
    userdata = userdata.replace("\\", "/")
    return userdata

def get_kodi_addons():
    addons = xbmcvfs.translatePath("special://home/addons")
    addons = addons.replace("\\", "/")
    return addons










   















        
        
        
