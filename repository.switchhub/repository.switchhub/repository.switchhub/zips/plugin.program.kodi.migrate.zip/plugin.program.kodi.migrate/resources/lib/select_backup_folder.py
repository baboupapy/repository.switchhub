# -*- coding: utf-8 -*-
import xbmcgui
import xbmcvfs
import os

SETTINGS_FILE = os.path.join(
    os.getcwd(), "portable_data", "userdata", "kodi_migrate", "backup_path.txt"
)


def save_path(path):
    """Enregistre le chemin choisi par l'utilisateur."""
    xbmcvfs.mkdirs(os.path.dirname(SETTINGS_FILE))
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        f.write(path)


def load_path():
    """Charge le chemin mémorisé."""
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    return None


def choose_folder():
    """Demande à l'utilisateur de choisir un dossier."""
    dialog = xbmcgui.Dialog()

    folder = dialog.browse(
        3, "Choisir dossier de sauvegarde", "files", "", False, False, ""
    )

    if folder:
        save_path(folder)
        dialog.ok("Kodi Migrate", "Dossier sélectionné :\n" + folder)
        return folder

    dialog.ok("Kodi Migrate", "Aucun dossier sélectionné.")
    return None



   















        
        
        
