# -*- coding: utf-8 -*-

import os
import zipfile
import xbmcvfs

def kodi_to_real(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return path

def smb_to_local(path):
    """
    Copie un fichier SMB (ZIP) dans special://home/temp/
    pour que zipfile puisse l'ouvrir.
    Ne tente jamais de détecter un dossier SMB (Kodi 21+ ne le permet pas).
    """
    if not path.lower().startswith("smb://"):
        return path

    # Si c'est un dossier SMB → on ne peut pas le copier → on le retourne tel quel
    if path.endswith("/") or path.endswith("\\"):
        return path

    temp_dir = xbmcvfs.translatePath("special://home/temp/")
    if not xbmcvfs.exists(temp_dir):
        xbmcvfs.mkdirs(temp_dir)

    local_path = os.path.join(temp_dir, os.path.basename(path))

    # Copie du fichier SMB → local
    xbmcvfs.copy(path, local_path)

    return local_path

def get_backup_type(zip_path):
    zip_path_real = kodi_to_real(zip_path)

    try:
        zin = zipfile.ZipFile(zip_path_real, "r")
    except Exception:
        return "unknown"

    names = zin.namelist()
    if not names:
        return "unknown"

    norm = [n.replace("\\", "/").lstrip("./") for n in names]

    root = ""
    for n in norm:
        if n.endswith("type.txt"):
            root = n.replace("type.txt", "")
            break

    def has_folder(folder):
        folder = folder.replace("\\", "/")
        if root:
            folder = root + folder
        for n in norm:
            if n.startswith(folder):
                return True
        return False

    if has_folder("addon_data/"):
        return "simple"

    if has_folder("addons/") and has_folder("userdata/"):
        return "full"

    return "unknown"

















   















        
        
        
