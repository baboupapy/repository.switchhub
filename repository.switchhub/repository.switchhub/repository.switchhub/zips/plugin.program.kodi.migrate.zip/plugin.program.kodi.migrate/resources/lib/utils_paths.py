# -*- coding: utf-8 -*-

import os
import xbmcvfs

def ensure_dir(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

def allowed_path(path):
    lower = path.lower()
    forbidden = ["temp", "cache", "thumbnails", "packages", "log"]
    return not any(x in lower for x in forbidden)

   















        
        
        
