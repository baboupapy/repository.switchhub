# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcvfs
import os
import platform

CONFIG_FILE = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.program.kodi.migrate/external_path.txt"
)


def load_external_path():
    """Retourne le chemin externe mémorisé, ou None."""
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    return None


def list_external_paths():
    paths = []

    system = platform.system().lower()

    # -------------------------
    # WINDOWS
    # -------------------------
    if system == "windows":
        for letter in "DEFGHIJKLMNOPQRSTUVWXYZ":
            root = f"{letter}:\\"
            if os.path.exists(root):
                paths.append(root)

    # -------------------------
    # ANDROID
    # -------------------------
    elif system == "linux":
        # Android storage
        if os.path.exists("/storage"):
            for p in os.listdir("/storage"):
                full = os.path.join("/storage", p)
                if os.path.isdir(full) and "-" in p:  # ex: 1234-5678
                    paths.append(full)

        # OTG
        if os.path.exists("/storage/usbotg"):
            paths.append("/storage/usbotg")

        # media_rw
        if os.path.exists("/mnt/media_rw"):
            for p in os.listdir("/mnt/media_rw"):
                full = os.path.join("/mnt/media_rw", p)
                if os.path.isdir(full):
                    paths.append(full)

    # -------------------------
    # CORE ELEC / LIBREELEC
    # -------------------------
    if os.path.exists("/media"):
        for p in os.listdir("/media"):
            full = os.path.join("/media", p)
            if os.path.isdir(full):
                paths.append(full)

    # -------------------------
    # MACOS
    # -------------------------
    if os.path.exists("/Volumes"):
        for p in os.listdir("/Volumes"):
            full = os.path.join("/Volumes", p)
            if os.path.isdir(full):
                paths.append(full)

    return paths


def choose_folder():
    paths = list_external_paths()

    if not paths:
        xbmcgui.Dialog().ok(
            "Kodi Migrate",
            "Aucun disque externe détecté.\n"
            "Sur Android 11+, utilisez SAF."
        )
        return

    dialog = xbmcgui.Dialog()
    choice = dialog.select("Choisir un disque externe", paths)

    if choice == -1:
        return

    selected = paths[choice]

    # Sauvegarde du choix dans addon_data
    addon_data = xbmcvfs.translatePath("special://userdata/addon_data/plugin.program.kodi.migrate")
    if not xbmcvfs.exists(addon_data):
        xbmcvfs.mkdirs(addon_data)

    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        f.write(selected)

    xbmcgui.Dialog().notification(
        "Kodi Migrate",
        f"Dossier externe sélectionné : {selected}",
        xbmcgui.NOTIFICATION_INFO,
        5000
    )

