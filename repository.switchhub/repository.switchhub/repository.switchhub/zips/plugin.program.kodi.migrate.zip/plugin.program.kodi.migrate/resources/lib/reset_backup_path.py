# -*- coding: utf-8 -*-

import os
import xbmcgui
import xbmcvfs

CONFIG_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.program.kodi.migrate"
)

FILES = [
    "backup_path.txt",
    "external_path.txt",
    "saf_path.txt"
]


def reset():
    # Création du dossier si inexistant
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)

    removed = []

    for filename in FILES:
        full_path = os.path.join(CONFIG_DIR, filename)

        try:
            os.remove(full_path)
            removed.append(filename)
        except FileNotFoundError:
            pass
        except Exception as e:
            xbmcgui.Dialog().ok(
                "Kodi Migrate - Erreur",
                f"Impossible de supprimer {filename}\n{e}"
            )
            return

    if removed:
        xbmcgui.Dialog().ok(
            "Kodi Migrate",
            "Chemins réinitialisés :\n" + "\n".join(removed)
        )
    else:
        xbmcgui.Dialog().ok(
            "Kodi Migrate",
            "Aucun chemin enregistré à réinitialiser."
        )






   















        
        
        
